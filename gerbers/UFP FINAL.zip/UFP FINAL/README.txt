Outline is in .GTL layer

There is no .GTP or layer

All files made in Eagle Light v.6.5.0 for linux
